function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(() => {
        alert('Номер карты скопирован!');
    });
}

function drawChart(prices) {
    const canvas = document.getElementById('cryptoChart');
    const ctx = canvas.getContext('2d');
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    const maxPrice = Math.max(...prices.map(p => p[1]));
    const minPrice = Math.min(...prices.map(p => p[1]));
    const priceRange = maxPrice - minPrice;
    
    const width = canvas.width;
    const height = canvas.height;
    const stepX = width / (prices.length - 1);
    
    ctx.beginPath();
    ctx.strokeStyle = '#00A6A6';
    ctx.lineWidth = 2;
    
    prices.forEach((point, i) => {
        const x = i * stepX;
        const y = height - ((point[1] - minPrice) / priceRange) * height;
        if (i === 0) {
            ctx.moveTo(x, y);
        } else {
            ctx.lineTo(x, y);
        }
    });
    
    ctx.stroke();
}