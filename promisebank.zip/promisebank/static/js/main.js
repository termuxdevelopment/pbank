// PromiseBank Main JavaScript

document.addEventListener('DOMContentLoaded', function() {
    // Initialize animations
    initializeAnimations();
    
    // Initialize tooltips
    initializeTooltips();
    
    // Initialize auto-dismiss alerts
    initializeAlerts();
    
    // Initialize crypto price updates
    initializeCryptoPrices();
    
    // Initialize form validations
    initializeFormValidations();
});

// Animation Initialization
function initializeAnimations() {
    // Add entrance animations to cards
    const cards = document.querySelectorAll('.card');
    cards.forEach((card, index) => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(20px)';
        
        setTimeout(() => {
            card.style.transition = 'all 0.6s ease';
            card.style.opacity = '1';
            card.style.transform = 'translateY(0)';
        }, index * 100);
    });
    
    // Logo rotation on hover
    const logo = document.querySelector('.logo-animation');
    if (logo) {
        logo.addEventListener('mouseenter', function() {
            this.style.transform = 'rotate(360deg) scale(1.1)';
        });
        
        logo.addEventListener('mouseleave', function() {
            this.style.transform = 'rotate(0deg) scale(1)';
        });
    }
    
    // Button hover effects
    const buttons = document.querySelectorAll('.btn');
    buttons.forEach(button => {
        button.addEventListener('mouseenter', function() {
            if (!this.disabled) {
                this.style.transform = 'translateY(-2px)';
                this.style.boxShadow = '0 4px 12px rgba(0, 0, 0, 0.3)';
            }
        });
        
        button.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
            this.style.boxShadow = '';
        });
    });
}

// Tooltip Initialization
function initializeTooltips() {
    // Initialize Bootstrap tooltips if available
    if (typeof bootstrap !== 'undefined') {
        const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
        tooltipTriggerList.map(function(tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl);
        });
    }
}

// Alert Auto-dismiss
function initializeAlerts() {
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(alert => {
        // Auto-dismiss success alerts after 5 seconds
        if (alert.classList.contains('alert-success')) {
            setTimeout(() => {
                const bsAlert = new bootstrap.Alert(alert);
                bsAlert.close();
            }, 5000);
        }
    });
}

// Crypto Price Updates
function initializeCryptoPrices() {
    // Update crypto prices every 30 seconds
    updateCryptoPrices();
    setInterval(updateCryptoPrices, 30000);
}

function updateCryptoPrices() {
    fetch('/api/crypto_prices')
        .then(response => response.json())
        .then(data => {
            // Update price displays if they exist
            updatePriceDisplay('bitcoin', data.bitcoin);
            updatePriceDisplay('ethereum', data.ethereum);
            updatePriceDisplay('tether', data.tether);
        })
        .catch(error => {
            console.error('Error fetching crypto prices:', error);
        });
}

function updatePriceDisplay(crypto, priceData) {
    const priceElement = document.querySelector(`[data-crypto="${crypto}"] .price`);
    const changeElement = document.querySelector(`[data-crypto="${crypto}"] .change`);
    
    if (priceElement) {
        priceElement.textContent = formatNumber(priceData.price_uzs) + ' UZS';
    }
    
    if (changeElement) {
        const change = priceData.change_24h;
        changeElement.textContent = (change >= 0 ? '+' : '') + change.toFixed(2) + '%';
        changeElement.className = `change ${change >= 0 ? 'text-success' : 'text-danger'}`;
    }
}

// Form Validations
function initializeFormValidations() {
    // Real-time balance validation for transfer forms
    const transferForm = document.querySelector('form[action*="transfer"]');
    if (transferForm) {
        const amountInput = transferForm.querySelector('input[name="amount"]');
        const currencySelect = transferForm.querySelector('select[name="currency"]');
        
        if (amountInput && currencySelect) {
            amountInput.addEventListener('input', validateTransferAmount);
            currencySelect.addEventListener('change', validateTransferAmount);
        }
    }
    
    // Crypto purchase calculator
    const cryptoForm = document.querySelector('form[action*="buy_crypto"]');
    if (cryptoForm) {
        const amountInput = cryptoForm.querySelector('input[name="amount_uzs"]');
        const cryptoSelect = cryptoForm.querySelector('select[name="crypto_type"]');
        
        if (amountInput && cryptoSelect) {
            amountInput.addEventListener('input', calculateCryptoAmount);
            cryptoSelect.addEventListener('change', calculateCryptoAmount);
        }
    }
}

function validateTransferAmount() {
    const form = this.closest('form');
    const amountInput = form.querySelector('input[name="amount"]');
    const currencySelect = form.querySelector('select[name="currency"]');
    const submitButton = form.querySelector('button[type="submit"]');
    
    const amount = parseFloat(amountInput.value) || 0;
    const currency = currencySelect.value;
    
    // Get current balances from the page
    const balances = getCurrentBalances();
    
    let isValid = true;
    let errorMessage = '';
    
    if (amount <= 0) {
        isValid = false;
        errorMessage = 'Сумма должна быть больше 0';
    } else {
        switch (currency) {
            case 'UZS':
                if (amount > balances.uzs) {
                    isValid = false;
                    errorMessage = 'Недостаточно средств UZS';
                }
                break;
            case 'BTC':
                if (amount > balances.btc) {
                    isValid = false;
                    errorMessage = 'Недостаточно Bitcoin';
                }
                break;
            case 'ETH':
                if (amount > balances.eth) {
                    isValid = false;
                    errorMessage = 'Недостаточно Ethereum';
                }
                break;
            case 'USDT':
                if (amount > balances.usdt) {
                    isValid = false;
                    errorMessage = 'Недостаточно Tether';
                }
                break;
        }
    }
    
    // Update UI
    const errorDiv = form.querySelector('.validation-error') || createErrorDiv();
    if (!form.querySelector('.validation-error')) {
        amountInput.parentNode.appendChild(errorDiv);
    }
    
    if (isValid) {
        errorDiv.style.display = 'none';
        amountInput.classList.remove('is-invalid');
        amountInput.classList.add('is-valid');
        submitButton.disabled = false;
    } else {
        errorDiv.textContent = errorMessage;
        errorDiv.style.display = 'block';
        amountInput.classList.remove('is-valid');
        amountInput.classList.add('is-invalid');
        submitButton.disabled = true;
    }
}

function calculateCryptoAmount() {
    const form = this.closest('form');
    const amountInput = form.querySelector('input[name="amount_uzs"]');
    const cryptoSelect = form.querySelector('select[name="crypto_type"]');
    const estimatedDiv = form.querySelector('#estimated-amount');
    
    if (!estimatedDiv) return;
    
    const amountUzs = parseFloat(amountInput.value) || 0;
    const cryptoType = cryptoSelect.value;
    
    if (amountUzs > 0 && window.cryptoPrices && window.cryptoPrices[cryptoType]) {
        const cryptoAmount = amountUzs / window.cryptoPrices[cryptoType];
        estimatedDiv.textContent = `≈ ${cryptoAmount.toFixed(6)} ${cryptoType}`;
        estimatedDiv.className = 'fw-bold text-primary';
    } else {
        estimatedDiv.textContent = 'Введите сумму для расчёта';
        estimatedDiv.className = 'fw-bold text-muted';
    }
}

function getCurrentBalances() {
    // Extract balances from the balance display on the page
    const balanceInfo = document.querySelector('.alert-info');
    if (!balanceInfo) return { uzs: 0, btc: 0, eth: 0, usdt: 0 };
    
    const balanceTexts = balanceInfo.querySelectorAll('.fw-bold');
    return {
        uzs: parseFloat(balanceTexts[0]?.textContent.replace(/,/g, '')) || 0,
        btc: parseFloat(balanceTexts[1]?.textContent) || 0,
        eth: parseFloat(balanceTexts[2]?.textContent) || 0,
        usdt: parseFloat(balanceTexts[3]?.textContent) || 0
    };
}

function createErrorDiv() {
    const div = document.createElement('div');
    div.className = 'validation-error text-danger small mt-1';
    div.style.display = 'none';
    return div;
}

// Utility Functions
function formatNumber(num) {
    return new Intl.NumberFormat('ru-RU').format(Math.round(num));
}

function formatCurrency(amount, currency) {
    switch (currency) {
        case 'UZS':
            return `${formatNumber(amount)} UZS`;
        case 'BTC':
        case 'ETH':
            return `${amount.toFixed(6)} ${currency}`;
        case 'USDT':
            return `${amount.toFixed(2)} ${currency}`;
        default:
            return `${amount} ${currency}`;
    }
}

// Loading State Management
function showLoading(element) {
    const original = element.innerHTML;
    element.innerHTML = '<span class="loading"></span> Загрузка...';
    element.disabled = true;
    return original;
}

function hideLoading(element, originalContent) {
    element.innerHTML = originalContent;
    element.disabled = false;
}

// Smooth Scrolling
function smoothScrollTo(target) {
    const element = document.querySelector(target);
    if (element) {
        element.scrollIntoView({
            behavior: 'smooth',
            block: 'start'
        });
    }
}

// Copy to Clipboard
function copyToClipboard(text, successMessage = 'Скопировано!') {
    navigator.clipboard.writeText(text).then(() => {
        showToast(successMessage, 'success');
    }).catch(() => {
        // Fallback for older browsers
        const textArea = document.createElement('textarea');
        textArea.value = text;
        document.body.appendChild(textArea);
        textArea.select();
        document.execCommand('copy');
        document.body.removeChild(textArea);
        showToast(successMessage, 'success');
    });
}

// Toast Notifications
function showToast(message, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `alert alert-${type} position-fixed`;
    toast.style.cssText = 'top: 20px; right: 20px; z-index: 9999; min-width: 300px;';
    toast.innerHTML = `
        ${message}
        <button type="button" class="btn-close" onclick="this.parentElement.remove()"></button>
    `;
    
    document.body.appendChild(toast);
    
    // Auto-remove after 3 seconds
    setTimeout(() => {
        if (toast.parentElement) {
            toast.remove();
        }
    }, 3000);
}

// Keyboard Shortcuts
document.addEventListener('keydown', function(e) {
    // Ctrl/Cmd + K for search (if search exists)
    if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
        e.preventDefault();
        const searchInput = document.querySelector('input[type="search"], input[name="search"]');
        if (searchInput) {
            searchInput.focus();
        }
    }
    
    // ESC to close modals
    if (e.key === 'Escape') {
        const openModal = document.querySelector('.modal.show');
        if (openModal) {
            const modal = bootstrap.Modal.getInstance(openModal);
            if (modal) modal.hide();
        }
    }
});

// Page Visibility API for crypto price updates
document.addEventListener('visibilitychange', function() {
    if (document.visibilityState === 'visible') {
        // Update prices when page becomes visible
        updateCryptoPrices();
    }
});

// Error Handling
window.addEventListener('error', function(e) {
    console.error('JavaScript Error:', e.error);
    // You could send this to a logging service
});

// Network Status
window.addEventListener('online', function() {
    showToast('Соединение восстановлено', 'success');
    updateCryptoPrices();
});

window.addEventListener('offline', function() {
    showToast('Нет подключения к интернету', 'warning');
});
