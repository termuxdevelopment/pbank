from flask import render_template, request, redirect, url_for, flash, jsonify
from flask_login import login_user, logout_user, login_required, current_user
from werkzeug.security import check_password_hash, generate_password_hash
from app import app, db
from models import User, VirtualCard, Transfer, Banner, WithdrawalRequest, CryptoPurchase
from forms import LoginForm, RegisterForm, TransferForm, WithdrawForm, CryptoPurchaseForm, BannerForm, AdminTopUpForm
from crypto_api import get_crypto_prices, convert_crypto_to_uzs, convert_uzs_to_crypto
import random
import string

@app.route('/')
def index():
    banners = Banner.query.filter_by(is_active=True).all()
    return render_template('index.html', banners=banners)

@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(username=form.username.data).first()
        if user and check_password_hash(user.password_hash, form.password.data):
            login_user(user)
            return redirect(url_for('dashboard'))
        flash('Неверное имя пользователя или пароль', 'danger')
    return render_template('login.html', form=form)

@app.route('/register', methods=['GET', 'POST'])
def register():
    form = RegisterForm()
    if form.validate_on_submit():
        # Create user
        user = User(
            username=form.username.data,
            email=form.email.data,
            password_hash=generate_password_hash(form.password.data)
        )
        db.session.add(user)
        db.session.flush()  # Get user ID
        
        # Create virtual card
        card_id = ''.join(random.choices(string.ascii_uppercase + string.digits, k=12))
        card = VirtualCard(
            card_id=card_id,
            user_id=user.id
        )
        db.session.add(card)
        db.session.commit()
        
        flash('Регистрация успешна! Ваша виртуальная карта создана.', 'success')
        return redirect(url_for('login'))
    
    return render_template('register.html', form=form)

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('index'))

@app.route('/dashboard')
@login_required
def dashboard():
    card = current_user.virtual_card
    crypto_prices = get_crypto_prices()
    
    # Calculate total portfolio value
    portfolio_value = card.balance
    if card.bitcoin > 0:
        portfolio_value += card.bitcoin * crypto_prices['bitcoin']['price_uzs']
    if card.ethereum > 0:
        portfolio_value += card.ethereum * crypto_prices['ethereum']['price_uzs']
    if card.tether > 0:
        portfolio_value += card.tether * crypto_prices['tether']['price_uzs']
    
    # Get recent transfers
    recent_transfers = Transfer.query.filter(
        (Transfer.sender_id == current_user.id) | 
        (Transfer.receiver_id == current_user.id)
    ).order_by(Transfer.created_at.desc()).limit(5).all()
    
    return render_template('dashboard.html', 
                         card=card, 
                         crypto_prices=crypto_prices,
                         portfolio_value=portfolio_value,
                         recent_transfers=recent_transfers)

@app.route('/transfer', methods=['GET', 'POST'])
@login_required
def transfer():
    form = TransferForm()
    if form.validate_on_submit():
        recipient = User.query.filter_by(username=form.recipient_username.data).first()
        if not recipient:
            flash('Получатель не найден', 'danger')
            return render_template('transfer.html', form=form)
        
        if recipient.id == current_user.id:
            flash('Нельзя переводить самому себе', 'danger')
            return render_template('transfer.html', form=form)
        
        sender_card = current_user.virtual_card
        recipient_card = recipient.virtual_card
        
        if not sender_card.is_active:
            flash('Ваша карта заблокирована', 'danger')
            return render_template('transfer.html', form=form)
        
        if not recipient_card.is_active:
            flash('Карта получателя заблокирована', 'danger')
            return render_template('transfer.html', form=form)
        
        # Check balance
        currency = form.currency.data
        amount = form.amount.data
        
        if currency == 'UZS':
            if sender_card.balance < amount:
                flash('Недостаточно средств', 'danger')
                return render_template('transfer.html', form=form)
            sender_card.balance -= amount
            recipient_card.balance += amount
        elif currency == 'BTC':
            if sender_card.bitcoin < amount:
                flash('Недостаточно Bitcoin', 'danger')
                return render_template('transfer.html', form=form)
            sender_card.bitcoin -= amount
            recipient_card.bitcoin += amount
        elif currency == 'ETH':
            if sender_card.ethereum < amount:
                flash('Недостаточно Ethereum', 'danger')
                return render_template('transfer.html', form=form)
            sender_card.ethereum -= amount
            recipient_card.ethereum += amount
        elif currency == 'USDT':
            if sender_card.tether < amount:
                flash('Недостаточно Tether', 'danger')
                return render_template('transfer.html', form=form)
            sender_card.tether -= amount
            recipient_card.tether += amount
        
        # Create transfer record
        transfer = Transfer(
            sender_id=current_user.id,
            receiver_id=recipient.id,
            amount=amount,
            currency=currency
        )
        
        db.session.add(transfer)
        db.session.commit()
        
        flash(f'Перевод {amount} {currency} отправлен пользователю {recipient.username}', 'success')
        return redirect(url_for('dashboard'))
    
    return render_template('transfer.html', form=form)

@app.route('/withdraw', methods=['GET', 'POST'])
@login_required
def withdraw():
    form = WithdrawForm()
    if form.validate_on_submit():
        card = current_user.virtual_card
        currency = form.currency.data
        amount = form.amount.data
        
        # Check if user has enough balance
        has_balance = False
        if currency == 'UZS' and card.balance >= amount:
            has_balance = True
        elif currency == 'BTC' and card.bitcoin >= amount:
            has_balance = True
        elif currency == 'ETH' and card.ethereum >= amount:
            has_balance = True
        elif currency == 'USDT' and card.tether >= amount:
            has_balance = True
        
        if not has_balance:
            flash('Недостаточно средств', 'danger')
            return render_template('withdraw.html', form=form)
        
        # Create withdrawal request
        withdrawal = WithdrawalRequest(
            user_id=current_user.id,
            amount=amount,
            currency=currency
        )
        db.session.add(withdrawal)
        db.session.commit()
        
        flash('Заявка на вывод отправлена. Свяжитесь с менеджером @promisebank_ru', 'info')
        return redirect(url_for('dashboard'))
    
    return render_template('withdraw.html', form=form)

@app.route('/buy_crypto', methods=['GET', 'POST'])
@login_required
def buy_crypto():
    form = CryptoPurchaseForm()
    crypto_prices = get_crypto_prices()
    
    if form.validate_on_submit():
        crypto_type = form.crypto_type.data
        amount_uzs = form.amount_uzs.data
        crypto_amount = convert_uzs_to_crypto(crypto_type, amount_uzs)
        
        # Create purchase request
        purchase = CryptoPurchase(
            user_id=current_user.id,
            crypto_type=crypto_type,
            amount_uzs=amount_uzs,
            crypto_amount=crypto_amount
        )
        db.session.add(purchase)
        db.session.commit()
        
        flash('Заявка на покупку криптовалюты отправлена. Свяжитесь с менеджером @promisebank_ru', 'info')
        return redirect(url_for('dashboard'))
    
    return render_template('buy_crypto.html', form=form, crypto_prices=crypto_prices)

@app.route('/admin')
@login_required
def admin():
    if not current_user.is_admin:
        flash('Доступ запрещен', 'danger')
        return redirect(url_for('dashboard'))
    
    users = User.query.all()
    cards = VirtualCard.query.all()
    banners = Banner.query.all()
    withdrawals = WithdrawalRequest.query.filter_by(status='pending').all()
    crypto_purchases = CryptoPurchase.query.filter_by(status='pending').all()
    
    return render_template('admin.html', 
                         users=users, 
                         cards=cards, 
                         banners=banners,
                         withdrawals=withdrawals,
                         crypto_purchases=crypto_purchases)

@app.route('/admin/toggle_card/<int:card_id>')
@login_required
def toggle_card(card_id):
    if not current_user.is_admin:
        flash('Доступ запрещен', 'danger')
        return redirect(url_for('dashboard'))
    
    card = VirtualCard.query.get_or_404(card_id)
    card.is_active = not card.is_active
    db.session.commit()
    
    status = "активирована" if card.is_active else "заблокирована"
    flash(f'Карта {card.card_id} {status}', 'success')
    return redirect(url_for('admin'))

@app.route('/admin/topup', methods=['POST'])
@login_required
def admin_topup():
    if not current_user.is_admin:
        flash('Доступ запрещен', 'danger')
        return redirect(url_for('dashboard'))
    
    user_id = request.form.get('user_id')
    amount = float(request.form.get('amount'))
    currency = request.form.get('currency')
    
    user = User.query.get(user_id)
    if user and user.virtual_card:
        card = user.virtual_card
        if currency == 'UZS':
            card.balance += amount
        elif currency == 'BTC':
            card.bitcoin += amount
        elif currency == 'ETH':
            card.ethereum += amount
        elif currency == 'USDT':
            card.tether += amount
        
        db.session.commit()
        flash(f'Счет пользователя {user.username} пополнен на {amount} {currency}', 'success')
    
    return redirect(url_for('admin'))

@app.route('/admin/banner', methods=['POST'])
@login_required
def add_banner():
    if not current_user.is_admin:
        flash('Доступ запрещен', 'danger')
        return redirect(url_for('dashboard'))
    
    title = request.form.get('title')
    content = request.form.get('content')
    
    banner = Banner(title=title, content=content)
    db.session.add(banner)
    db.session.commit()
    
    flash('Баннер добавлен', 'success')
    return redirect(url_for('admin'))
