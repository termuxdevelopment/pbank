import requests
import logging

def get_crypto_prices():
    """Get current cryptocurrency prices from CoinGecko API"""
    try:
        url = "https://api.coingecko.com/api/v3/simple/price"
        params = {
            'ids': 'bitcoin,ethereum,tether',
            'vs_currencies': 'usd',
            'include_24hr_change': 'true'
        }
        
        response = requests.get(url, params=params, timeout=10)
        response.raise_for_status()
        
        data = response.json()
        
        # Convert to a more convenient format
        prices = {
            'bitcoin': {
                'price_usd': data.get('bitcoin', {}).get('usd', 0),
                'change_24h': data.get('bitcoin', {}).get('usd_24h_change', 0)
            },
            'ethereum': {
                'price_usd': data.get('ethereum', {}).get('usd', 0),
                'change_24h': data.get('ethereum', {}).get('usd_24h_change', 0)
            },
            'tether': {
                'price_usd': data.get('tether', {}).get('usd', 1),
                'change_24h': data.get('tether', {}).get('usd_24h_change', 0)
            }
        }
        
        # Convert to UZS (approximate rate: 1 USD = 12500 UZS)
        usd_to_uzs = 12500
        for crypto in prices:
            prices[crypto]['price_uzs'] = prices[crypto]['price_usd'] * usd_to_uzs
        
        return prices
        
    except Exception as e:
        logging.error(f"Error fetching crypto prices: {e}")
        # Return default/fallback prices
        return {
            'bitcoin': {'price_usd': 45000, 'price_uzs': 562500000, 'change_24h': 0},
            'ethereum': {'price_usd': 2500, 'price_uzs': 31250000, 'change_24h': 0},
            'tether': {'price_usd': 1, 'price_uzs': 12500, 'change_24h': 0}
        }

def convert_crypto_to_uzs(crypto_type, amount):
    """Convert cryptocurrency amount to UZS"""
    prices = get_crypto_prices()
    crypto_map = {
        'BTC': 'bitcoin',
        'ETH': 'ethereum',
        'USDT': 'tether'
    }
    
    if crypto_type in crypto_map:
        crypto_key = crypto_map[crypto_type]
        return amount * prices[crypto_key]['price_uzs']
    return 0

def convert_uzs_to_crypto(crypto_type, uzs_amount):
    """Convert UZS amount to cryptocurrency"""
    prices = get_crypto_prices()
    crypto_map = {
        'BTC': 'bitcoin',
        'ETH': 'ethereum',
        'USDT': 'tether'
    }
    
    if crypto_type in crypto_map:
        crypto_key = crypto_map[crypto_type]
        if prices[crypto_key]['price_uzs'] > 0:
            return uzs_amount / prices[crypto_key]['price_uzs']
    return 0
