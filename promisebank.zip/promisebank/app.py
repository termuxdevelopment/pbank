from flask import Flask, render_template, redirect, url_for, flash, request
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField, FloatField, TextAreaField
from wtforms.validators import DataRequired, Length, NumberRange
import sqlite3
import requests
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
import random

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your-secret-key'

login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

# Модель пользователя
class User(UserMixin):
    def __init__(self, id, username, email, password_hash, role, registration_date):
        self.id = id
        self.username = username
        self.email = email
        self.password_hash = password_hash
        self.role = role
        self.registration_date = registration_date

# Формы
class LoginForm(FlaskForm):
    username = StringField('Имя пользователя', validators=[DataRequired(), Length(max=26)])
    password = PasswordField('Пароль', validators=[DataRequired(), Length(min=6, max=26)])
    submit = SubmitField('Войти')

class RegisterForm(FlaskForm):
    username = StringField('Имя пользователя', validators=[DataRequired(), Length(max=26)])
    email = StringField('Email', validators=[DataRequired(), Length(max=26)])
    password = PasswordField('Пароль', validators=[DataRequired(), Length(min=6, max=26)])
    confirm_password = PasswordField('Подтвердите пароль', validators=[DataRequired(), Length(max=26)])
    submit = SubmitField('Зарегистрироваться')

class TransferForm(FlaskForm):
    card_id = StringField('ID карты получателя', validators=[DataRequired()])
    amount = FloatField('Сумма (USD)', validators=[DataRequired(), NumberRange(min=1, max=1500)])
    message = TextAreaField('Сообщение', validators=[Length(max=100)])
    submit = SubmitField('Перевести')

class DepositForm(FlaskForm):
    amount = FloatField('Сумма (USD)', validators=[DataRequired(), NumberRange(min=1)])
    submit = SubmitField('Отправить запрос')

class WithdrawForm(FlaskForm):
    amount = FloatField('Сумма (USD)', validators=[DataRequired(), NumberRange(min=1)])
    submit = SubmitField('Отправить запрос')

class BuyCryptoForm(FlaskForm):
    crypto = StringField('Криптовалюта (BTC, ETH, USDT)', validators=[DataRequired()])
    amount = FloatField('Сумма (USD)', validators=[DataRequired(), NumberRange(min=1)])
    submit = SubmitField('Отправить запрос')

class AdminDepositForm(FlaskForm):
    card_id = StringField('ID карты', validators=[DataRequired()])
    amount = FloatField('Сумма (USD)', validators=[DataRequired(), NumberRange(min=0)])
    submit = SubmitField('Пополнить')

# Инициализация базы данных
def init_db():
    conn = sqlite3.connect('promisebank.db')
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        role TEXT DEFAULT 'user',
        registration_date TEXT NOT NULL
    )''')
    c.execute('''CREATE TABLE IF NOT EXISTS cards (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        card_number TEXT UNIQUE NOT NULL,
        balance_usd REAL DEFAULT 0.0,
        btc_balance REAL DEFAULT 0.0,
        eth_balance REAL DEFAULT 0.0,
        usdt_balance REAL DEFAULT 0.0,
        status TEXT DEFAULT 'active',
        FOREIGN KEY (user_id) REFERENCES users (id)
    )''')
    conn.commit()
    conn.close()

# Генерация номера карты
def generate_card_number():
    return '4123' + ''.join([str(random.randint(0, 9)) for _ in range(12)])

# Получение курсов криптовалют
def get_crypto_prices():
    url = 'https://api.coingecko.com/api/v3/simple/price?ids=bitcoin,ethereum,tether&vs_currencies=usd'
    try:
        response = requests.get(url)
        return response.json()
    except:
        return {'bitcoin': {'usd': 0}, 'ethereum': {'usd': 0}, 'tether': {'usd': 0}}

# Получение данных для графика
def get_crypto_chart(crypto):
    url = f'https://api.coingecko.com/api/v3/coins/{crypto}/market_chart?vs_currency=usd&days=1'
    try:
        response = requests.get(url)
        data = response.json()
        return {
            'prices': data['prices'],
            'market_caps': data['market_caps'],
            'total_volumes': data['total_volumes']
        }
    except:
        return {'prices': [], 'market_caps': [], 'total_volumes': []}

@login_manager.user_loader
def load_user(user_id):
    conn = sqlite3.connect('promisebank.db')
    c = conn.cursor()
    c.execute('SELECT id, username, email, password_hash, role, registration_date FROM users WHERE id = ?', (user_id,))
    user_data = c.fetchone()
    conn.close()
    if user_data:
        return User(user_data[0], user_data[1], user_data[2], user_data[3], user_data[4], user_data[5])
    return None

@app.route('/')
def index():
    return render_template('index.html', telegram='@promisebank_ru', email='promisebank@mail.ru')

@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        conn = sqlite3.connect('promisebank.db')
        c = conn.cursor()
        c.execute('SELECT id, username, email, password_hash, role, registration_date FROM users WHERE username = ?', (form.username.data,))
        user_data = c.fetchone()
        conn.close()
        if user_data and check_password_hash(user_data[3], form.password.data):
            user = User(user_data[0], user_data[1], user_data[2], user_data[3], user_data[4], user_data[5])
            login_user(user)
            if user.role == 'admin':
                return redirect(url_for('admin'))
            return redirect(url_for('dashboard'))
        flash('Неверное имя пользователя или пароль')
    return render_template('login.html', form=form)

@app.route('/register', methods=['GET', 'POST'])
def register():
    form = RegisterForm()
    if form.validate_on_submit():
        if form.password.data != form.confirm_password.data:
            flash('Пароли не совпадают')
            return render_template('register.html', form=form)
        conn = sqlite3.connect('promisebank.db')
        c = conn.cursor()
        try:
            password_hash = generate_password_hash(form.password.data)
            registration_date = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            c.execute('INSERT INTO users (username, email, password_hash, registration_date) VALUES (?, ?, ?, ?)',
                      (form.username.data, form.email.data, password_hash, registration_date))
            user_id = c.lastrowid
            card_number = generate_card_number()
            c.execute('INSERT INTO cards (user_id, card_number) VALUES (?, ?)', (user_id, card_number))
            conn.commit()
            flash('Регистрация успешна! Войдите в систему.')
            return redirect(url_for('login'))
        except sqlite3.IntegrityError:
            flash('Имя пользователя или email уже заняты.')
        finally:
            conn.close()
    return render_template('register.html', form=form)

@app.route('/dashboard')
@login_required
def dashboard():
    conn = sqlite3.connect('promisebank.db')
    c = conn.cursor()
    c.execute('SELECT id, card_number, balance_usd, btc_balance, eth_balance, usdt_balance, status FROM cards WHERE user_id = ?', (current_user.id,))
    card = c.fetchone()
    conn.close()
    prices = get_crypto_prices()
    return render_template('dashboard.html', card=card, prices=prices)

@app.route('/crypto/<crypto>')
@login_required
def crypto_chart(crypto):
    chart_data = get_crypto_chart(crypto)
    prices = get_crypto_prices()
    return render_template('crypto_chart.html', crypto=crypto, chart_data=chart_data, prices=prices)

@app.route('/transfer', methods=['GET', 'POST'])
@login_required
def transfer():
    form = TransferForm()
    if form.validate_on_submit():
        conn = sqlite3.connect('promisebank.db')
        c = conn.cursor()
        c.execute('SELECT id, balance_usd, status FROM cards WHERE user_id = ?', (current_user.id,))
        sender_card = c.fetchone()
        c.execute('SELECT id, balance_usd, status FROM cards WHERE id = ?', (form.card_id.data,))
        receiver_card = c.fetchone()
        if not sender_card or not receiver_card:
            flash('Карта не найдена')
        elif sender_card[2] != 'active' or receiver_card[2] != 'active':
            flash('Одна из карт заблокирована')
        elif sender_card[1] < form.amount.data:
            flash('Недостаточно средств')
        else:
            c.execute('UPDATE cards SET balance_usd = balance_usd - ? WHERE id = ?', (form.amount.data, sender_card[0]))
            c.execute('UPDATE cards SET balance_usd = balance_usd + ? WHERE id = ?', (form.amount.data, receiver_card[0]))
            conn.commit()
            flash('Перевод успешно выполнен')
            return redirect(url_for('dashboard'))
        conn.close()
    return render_template('transfer.html', form=form)

@app.route('/deposit', methods=['GET', 'POST'])
@login_required
def deposit():
    form = DepositForm()
    if form.validate_on_submit():
        flash(f'Запрос на пополнение на ${form.amount.data} отправлен менеджеру (@promisebank_ru)')
        return redirect(url_for('dashboard'))
    return render_template('deposit.html', form=form)

@app.route('/withdraw', methods=['GET', 'POST'])
@login_required
def withdraw():
    form = WithdrawForm()
    if form.validate_on_submit():
        flash(f'Запрос на вывод ${form.amount.data} отправлен менеджеру (@promisebank_ru)')
        return redirect(url_for('dashboard'))
    return render_template('withdraw.html', form=form)

@app.route('/buy_crypto', methods=['GET', 'POST'])
@login_required
def buy_crypto():
    form = BuyCryptoForm()
    if form.validate_on_submit():
        flash(f'Запрос на покупку {form.crypto.data} на ${form.amount.data} отправлен менеджеру (@promisebank_ru)')
        return redirect(url_for('dashboard'))
    return render_template('buy_crypto.html', form=form)

@app.route('/admin', methods=['GET', 'POST'])
@login_required
def admin():
    if current_user.role != 'admin':
        return redirect(url_for('dashboard'))
    deposit_form = AdminDepositForm()
    if deposit_form.validate_on_submit():
        conn = sqlite3.connect('promisebank.db')
        c = conn.cursor()
        c.execute('SELECT id FROM cards WHERE id = ?', (deposit_form.card_id.data,))
        card = c.fetchone()
        if card:
            c.execute('UPDATE cards SET balance_usd = balance_usd + ? WHERE id = ?', (deposit_form.amount.data, deposit_form.card_id.data))
            conn.commit()
            flash('Карта успешно пополнена')
        else:
            flash('Карта не найдена')
        conn.close()
    conn = sqlite3.connect('promisebank.db')
    c = conn.cursor()
    c.execute('SELECT id, username, email, registration_date FROM users')
    users = c.fetchall()
    c.execute('SELECT id, user_id, card_number, balance_usd, btc_balance, eth_balance, usdt_balance, status FROM cards')
    cards = c.fetchall()
    conn.close()
    return render_template('admin.html', users=users, cards=cards, deposit_form=deposit_form)

@app.route('/admin/block_card/<int:card_id>')
@login_required
def block_card(card_id):
    if current_user.role != 'admin':
        return redirect(url_for('dashboard'))
    conn = sqlite3.connect('promisebank.db')
    c = conn.cursor()
    c.execute('UPDATE cards SET status = ? WHERE id = ?', ('blocked', card_id))
    conn.commit()
    conn.close()
    flash('Карта заблокирована')
    return redirect(url_for('admin'))

@app.route('/admin/unblock_card/<int:card_id>')
@login_required
def unblock_card(card_id):
    if current_user.role != 'admin':
        return redirect(url_for('dashboard'))
    conn = sqlite3.connect('promisebank.db')
    c = conn.cursor()
    c.execute('UPDATE cards SET status = ? WHERE id = ?', ('active', card_id))
    conn.commit()
    conn.close()
    flash('Карта разблокирована')
    return redirect(url_for('admin'))

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('index'))

if __name__ == '__main__':
    init_db()
    # Создание админа
    conn = sqlite3.connect('promisebank.db')
    c = conn.cursor()
    c.execute('SELECT * FROM users WHERE username = ?', ('Admin',))
    if not c.fetchone():
        password_hash = generate_password_hash('admin123')
        registration_date = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        c.execute('INSERT INTO users (username, email, password_hash, role, registration_date) VALUES (?, ?, ?, ?, ?)',
                  ('Admin', 'admin@promisebank.com', password_hash, 'admin', registration_date))
        conn.commit()
    conn.close()
    app.run(debug=True)