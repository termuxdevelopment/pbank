from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, FloatField, SelectField, TextAreaField, BooleanField
from wtforms.validators import DataRequired, Email, Length, NumberRange, ValidationError
from models import User

class LoginForm(FlaskForm):
    username = StringField('Имя пользователя', validators=[DataRequired()])
    password = PasswordField('Пароль', validators=[DataRequired()])

class RegisterForm(FlaskForm):
    username = StringField('Имя пользователя', validators=[DataRequired(), Length(min=3, max=20)])
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Пароль', validators=[DataRequired(), Length(min=6)])
    
    def validate_username(self, username):
        user = User.query.filter_by(username=username.data).first()
        if user:
            raise ValidationError('Это имя пользователя уже занято.')
    
    def validate_email(self, email):
        user = User.query.filter_by(email=email.data).first()
        if user:
            raise ValidationError('Этот email уже зарегистрирован.')

class TransferForm(FlaskForm):
    recipient_username = StringField('Имя получателя', validators=[DataRequired()])
    amount = FloatField('Сумма', validators=[DataRequired(), NumberRange(min=0.01)])
    currency = SelectField('Валюта', choices=[('UZS', 'UZS'), ('BTC', 'Bitcoin'), ('ETH', 'Ethereum'), ('USDT', 'Tether')])

class WithdrawForm(FlaskForm):
    amount = FloatField('Сумма', validators=[DataRequired(), NumberRange(min=0.01)])
    currency = SelectField('Валюта', choices=[('UZS', 'UZS'), ('BTC', 'Bitcoin'), ('ETH', 'Ethereum'), ('USDT', 'Tether')])

class CryptoPurchaseForm(FlaskForm):
    crypto_type = SelectField('Криптовалюта', choices=[('BTC', 'Bitcoin'), ('ETH', 'Ethereum'), ('USDT', 'Tether')])
    amount_uzs = FloatField('Сумма в UZS', validators=[DataRequired(), NumberRange(min=1)])

class BannerForm(FlaskForm):
    title = StringField('Заголовок', validators=[DataRequired(), Length(max=200)])
    content = TextAreaField('Содержание', validators=[DataRequired()])
    is_active = BooleanField('Активный')

class AdminTopUpForm(FlaskForm):
    user_id = SelectField('Пользователь', coerce=int, validators=[DataRequired()])
    amount = FloatField('Сумма', validators=[DataRequired(), NumberRange(min=0.01)])
    currency = SelectField('Валюта', choices=[('UZS', 'UZS'), ('BTC', 'Bitcoin'), ('ETH', 'Ethereum'), ('USDT', 'Tether')])
